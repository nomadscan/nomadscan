import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, LogOut, User, Mail, Calendar } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Profile() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const logoutMutation = trpc.auth.logout.useMutation();

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      toast.success("Desconectado com sucesso!");
      navigate("/");
    } catch (error) {
      toast.error("Erro ao desconectar");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold text-white">Meu Perfil</h1>
          <p className="text-slate-400">Gerencie suas informações pessoais</p>
        </div>

        {/* Profile Card */}
        <Card className="border-slate-700 bg-slate-800/50 p-8">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center">
                <User className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">{user.name || "Usuário"}</h2>
                <p className="text-slate-400">{user.email || "Sem email"}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4 border-t border-slate-700 pt-6">
            {/* Name */}
            <div>
              <label className="text-sm font-medium text-slate-300">Nome Completo</label>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-slate-700/50 px-4 py-3">
                <User className="h-4 w-4 text-slate-400" />
                <p className="text-white">{user.name || "Não informado"}</p>
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="text-sm font-medium text-slate-300">Email</label>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-slate-700/50 px-4 py-3">
                <Mail className="h-4 w-4 text-slate-400" />
                <p className="text-white">{user.email || "Não informado"}</p>
              </div>
            </div>

            {/* Role */}
            <div>
              <label className="text-sm font-medium text-slate-300">Tipo de Conta</label>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-slate-700/50 px-4 py-3">
                <span className="inline-flex items-center rounded-full bg-cyan-500/20 px-3 py-1 text-sm font-medium text-cyan-400 capitalize">
                  {user.role}
                </span>
              </div>
            </div>

            {/* Member Since */}
            <div>
              <label className="text-sm font-medium text-slate-300">Membro desde</label>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-slate-700/50 px-4 py-3">
                <Calendar className="h-4 w-4 text-slate-400" />
                <p className="text-white">
                  {new Date(user.createdAt).toLocaleDateString("pt-BR", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
            </div>

            {/* Last Signed In */}
            <div>
              <label className="text-sm font-medium text-slate-300">Último acesso</label>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-slate-700/50 px-4 py-3">
                <Calendar className="h-4 w-4 text-slate-400" />
                <p className="text-white">
                  {new Date(user.lastSignedIn).toLocaleDateString("pt-BR", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Settings Section */}
        <Card className="border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Configurações</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg bg-slate-700/50 p-4">
              <div>
                <p className="font-medium text-white">Notificações</p>
                <p className="text-sm text-slate-400">Receba alertas de missões e detecções</p>
              </div>
              <input type="checkbox" defaultChecked className="h-4 w-4" />
            </div>
            <div className="flex items-center justify-between rounded-lg bg-slate-700/50 p-4">
              <div>
                <p className="font-medium text-white">Dark Mode</p>
                <p className="text-sm text-slate-400">Tema escuro ativado</p>
              </div>
              <input type="checkbox" defaultChecked disabled className="h-4 w-4" />
            </div>
          </div>
        </Card>

        {/* Logout Section */}
        <Card className="border-red-500/30 bg-red-500/10 p-6">
          <h3 className="mb-4 text-lg font-semibold text-red-400">Zona de Perigo</h3>
          <p className="mb-4 text-sm text-slate-300">
            Desconecte-se da sua conta. Você precisará fazer login novamente para acessar a plataforma.
          </p>
          <Button
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
            className="bg-red-500 hover:bg-red-600 text-white"
          >
            <LogOut className="mr-2 h-4 w-4" />
            {logoutMutation.isPending ? "Desconectando..." : "Desconectar"}
          </Button>
        </Card>
      </div>
    </DashboardLayout>
  );
}
