import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, FileText, Download, RefreshCw, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function Reports() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: missions, isLoading } = trpc.missions.list.useQuery();
  const generateMutation = trpc.llm.generateMissionReport.useMutation();
  const [selectedMissionId, setSelectedMissionId] = useState<string>("");
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [reportType, setReportType] = useState<"full" | "summary">("full");

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleGenerateReport = async () => {
    if (!selectedMissionId) {
      toast.error("Selecione uma missão");
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateMutation.mutateAsync({
        missionId: parseInt(selectedMissionId),
      });
      setGeneratedReport(result.reportContent);
      setReportType("full");
      setShowReportDialog(true);
      toast.success("Relatório gerado com sucesso!");
    } catch (error) {
      toast.error("Erro ao gerar relatório");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSummarizeDetections = async () => {
    if (!selectedMissionId) {
      toast.error("Selecione uma missão");
      return;
    }

    setIsGenerating(true);
    try {
      // For now, we'll create a simple summary from available data
      const mission = missions?.find((m) => m.id === parseInt(selectedMissionId));
      if (!mission) {
        toast.error("Missão não encontrada");
        return;
      }

      const summary = `Resumo da Missão: ${mission.name}
      
Status: ${mission.status}
Descrição: ${mission.description || "Sem descrição"}
Data de Criação: ${new Date(mission.createdAt).toLocaleString("pt-BR")}

Este é um resumo automático da missão. Para uma análise completa com detecções, gere o relatório completo.`;

      setGeneratedReport(summary);
      setReportType("summary");
      setShowReportDialog(true);
      toast.success("Resumo gerado com sucesso!");
    } catch (error) {
      toast.error("Erro ao gerar resumo");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadReport = () => {
    if (!generatedReport) return;

    const element = document.createElement("a");
    const file = new Blob([generatedReport], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `relatorio-${selectedMissionId}-${Date.now()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("Relatório baixado!");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Relatórios de Missão</h1>
          <p className="text-slate-400">Gere relatórios automáticos com IA para suas missões</p>
        </div>

        {/* Generator Section */}
        <Card className="border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Gerar Novo Relatório</h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-300">Selecione uma Missão</label>
              <Select value={selectedMissionId} onValueChange={setSelectedMissionId}>
                <SelectTrigger className="mt-2 border-slate-600 bg-slate-700 text-white">
                  <SelectValue placeholder="Escolha uma missão" />
                </SelectTrigger>
                <SelectContent className="border-slate-600 bg-slate-700">
                  {missions?.map((mission) => (
                    <SelectItem key={mission.id} value={mission.id.toString()}>
                      {mission.name} ({mission.status})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleGenerateReport}
                disabled={isGenerating || !selectedMissionId}
                className="flex-1 bg-cyan-500 hover:bg-cyan-600"
              >
                <Sparkles className="mr-2 h-4 w-4" />
                {isGenerating ? "Gerando..." : "Gerar Relatório Completo"}
              </Button>
              <Button
                onClick={handleSummarizeDetections}
                disabled={isGenerating || !selectedMissionId}
                variant="outline"
                className="flex-1 border-slate-600"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                {isGenerating ? "Processando..." : "Resumir Detecções"}
              </Button>
            </div>
          </div>
        </Card>

        {/* Generated Report Preview */}
        {generatedReport && (
          <Card className="border-slate-700 bg-slate-800/50 p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Relatório Gerado</h3>
              <Button
                onClick={handleDownloadReport}
                variant="outline"
                size="sm"
                className="border-slate-600"
              >
                <Download className="mr-2 h-3 w-3" />
                Download
              </Button>
            </div>
            <div className="max-h-96 overflow-y-auto rounded-lg bg-slate-700/50 p-4">
              <Streamdown>{generatedReport}</Streamdown>
            </div>
          </Card>
        )}

        {/* Info Section */}
        <Card className="border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Como Funciona</h3>
          <div className="space-y-3 text-sm text-slate-300">
            <p>
              <strong>Relatório Completo:</strong> Gera um relatório profissional detalhado com análise de detecções, recomendações e conclusões usando inteligência artificial.
            </p>
            <p>
              <strong>Resumir Detecções:</strong> Cria um resumo conciso das informações da missão.
            </p>
            <p>
              Os relatórios podem ser baixados em formato de texto para compartilhamento ou arquivamento.
            </p>
          </div>
        </Card>
      </div>

      {/* Report Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="max-w-2xl border-slate-700 bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">
              {reportType === "full" ? "Relatório Completo" : "Resumo"}
            </DialogTitle>
          </DialogHeader>
          <div className="max-h-96 overflow-y-auto rounded-lg bg-slate-700/50 p-4">
            <Streamdown>{generatedReport || ""}</Streamdown>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleDownloadReport}
              className="flex-1 bg-cyan-500 hover:bg-cyan-600"
            >
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
            <Button
              onClick={() => setShowReportDialog(false)}
              variant="outline"
              className="flex-1 border-slate-600"
            >
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
