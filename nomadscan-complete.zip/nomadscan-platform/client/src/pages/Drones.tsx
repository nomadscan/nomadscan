import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, Plus, Battery, MapPin, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function Drones() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: drones, isLoading, refetch } = trpc.drones.list.useQuery();
  const createMutation = trpc.drones.create.useMutation();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    model: "",
    serialNumber: "",
  });

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync({
        name: formData.name,
        model: formData.model,
        serialNumber: formData.serialNumber,
      });
      toast.success("Drone registrado com sucesso!");
      setFormData({ name: "", model: "", serialNumber: "" });
      setIsOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao registrar drone");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/20 text-green-400";
      case "maintenance":
        return "bg-yellow-500/20 text-yellow-400";
      case "inactive":
        return "bg-orange-500/20 text-orange-400";
      default:
        return "bg-red-500/20 text-red-400";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Ativo";
      case "maintenance":
        return "Manutenção";
      case "inactive":
        return "Inativo";
      default:
        return "Offline";
    }
  };

  const getBatteryColor = (level: number) => {
    if (level >= 75) return "text-green-400";
    if (level >= 50) return "text-yellow-400";
    if (level >= 25) return "text-orange-400";
    return "text-red-400";
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Frota de Drones</h1>
            <p className="text-slate-400">Gerencie todos os seus drones</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-cyan-500 hover:bg-cyan-600">
                <Plus className="mr-2 h-4 w-4" />
                Registrar Drone
              </Button>
            </DialogTrigger>
            <DialogContent className="border-slate-700 bg-slate-800">
              <DialogHeader>
                <DialogTitle className="text-white">Registrar Novo Drone</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-300">Nome do Drone</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: DJI Mavic 3"
                    className="mt-1 border-slate-600 bg-slate-700 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300">Modelo</label>
                  <Input
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    placeholder="Ex: Mavic 3"
                    className="mt-1 border-slate-600 bg-slate-700 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300">Número de Série</label>
                  <Input
                    value={formData.serialNumber}
                    onChange={(e) => setFormData({ ...formData, serialNumber: e.target.value })}
                    placeholder="Ex: ABC123XYZ"
                    className="mt-1 border-slate-600 bg-slate-700 text-white"
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-600">
                  Registrar Drone
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Drones Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {drones && drones.length > 0 ? (
            drones.map((drone) => (
              <Card key={drone.id} className="border-slate-700 bg-slate-800/50 p-6">
                <div className="mb-4 flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{drone.name}</h3>
                    <p className="text-sm text-slate-400">{drone.model}</p>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-medium ${getStatusColor(drone.status)}`}>
                    {getStatusLabel(drone.status)}
                  </span>
                </div>

                <div className="space-y-3 border-t border-slate-700 pt-4">
                  {/* Battery */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Battery className="h-4 w-4" />
                      <span className="text-sm">Bateria</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-20 rounded-full bg-slate-700">
                        <div
                          className={`h-full rounded-full bg-gradient-to-r from-green-400 to-green-500 transition-all`}
                          style={{ width: `${drone.batteryLevel}%` }}
                        />
                      </div>
                      <span className={`text-sm font-semibold ${getBatteryColor(drone.batteryLevel)}`}>
                        {drone.batteryLevel}%
                      </span>
                    </div>
                  </div>

                  {/* Location */}
                  {drone.latitude && drone.longitude && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <MapPin className="h-4 w-4" />
                        <span className="text-sm">Localização</span>
                      </div>
                      <span className="text-sm text-slate-300">
                        {parseFloat(drone.latitude.toString()).toFixed(4)}, {parseFloat(drone.longitude.toString()).toFixed(4)}
                      </span>
                    </div>
                  )}

                  {/* Altitude */}
                  {drone.altitude && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Zap className="h-4 w-4" />
                        <span className="text-sm">Altitude</span>
                      </div>
                      <span className="text-sm text-slate-300">{drone.altitude}m</span>
                    </div>
                  )}

                  {/* Serial Number */}
                  <div className="text-xs text-slate-500">
                    SN: {drone.serialNumber}
                  </div>
                </div>

                {drone.lastLocationUpdate && (
                  <p className="mt-4 text-xs text-slate-600">
                    Atualizado: {new Date(drone.lastLocationUpdate).toLocaleTimeString("pt-BR")}
                  </p>
                )}
              </Card>
            ))
          ) : (
            <Card className="col-span-full border-slate-700 bg-slate-800/50 p-12 text-center">
              <p className="text-slate-400">Nenhum drone registrado ainda. Registre seu primeiro drone para começar!</p>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
