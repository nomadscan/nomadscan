import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight, Zap, Map, Radio, Brain, Cloud, FileText } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated && user) {
      navigate("/");
    }
  }, [isAuthenticated, user, navigate]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-950">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-black">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 backdrop-blur-md bg-slate-900/50 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/nomadscan-logo_900d50e6.png" alt="NomadScan" className="h-10 w-10 object-contain" />
            <span className="text-2xl font-bold text-white">NomadScan</span>
          </div>
          <Button
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
            className="bg-cyan-500 hover:bg-cyan-600 text-white"
          >
            Entrar
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Veja Além dos Limites
                </h1>
                <p className="text-xl text-slate-300">
                  Plataforma inteligente de monitoramento e gestão de drones com IA integrada. Controle sua frota em tempo real com precisão e segurança.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => {
                    window.location.href = getLoginUrl();
                  }}
                  size="lg"
                  className="bg-cyan-500 hover:bg-cyan-600 text-white text-lg h-12 px-8"
                >
                  Começar Agora
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-slate-600 text-white hover:bg-slate-800 text-lg h-12 px-8"
                >
                  Saiba Mais
                </Button>
              </div>

              <div className="flex items-center gap-6 pt-8 border-t border-slate-800">
                <div>
                  <p className="text-2xl font-bold text-cyan-400">100%</p>
                  <p className="text-sm text-slate-400">Uptime</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-cyan-400">Real-time</p>
                  <p className="text-sm text-slate-400">Monitoramento</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-cyan-400">AI-Powered</p>
                  <p className="text-sm text-slate-400">Detecções</p>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative h-96 lg:h-full min-h-96 flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-3xl blur-3xl" />
              <img
                src="/manus-storage/nomadscan-logo_900d50e6.png"
                alt="NomadScan"
                className="relative h-64 w-64 object-contain drop-shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Funcionalidades Poderosas</h2>
            <p className="text-lg text-slate-400">Tudo que você precisa para gerenciar sua frota de drones</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <Map className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Mapa Interativo</h3>
              <p className="text-slate-400">Visualize a posição em tempo real de todos os seus drones no mapa</p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <Radio className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Transmissão ao Vivo</h3>
              <p className="text-slate-400">Acompanhe a transmissão em tempo real com dados de telemetria</p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <Brain className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Detecção por IA</h3>
              <p className="text-slate-400">Identificação automática de objetos, pessoas e veículos</p>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <Cloud className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Armazenamento em Nuvem</h3>
              <p className="text-slate-400">Salve e organize suas imagens e vídeos de forma segura</p>
            </div>

            {/* Feature 5 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <FileText className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Relatórios Automáticos</h3>
              <p className="text-slate-400">Gere relatórios profissionais com IA em segundos</p>
            </div>

            {/* Feature 6 */}
            <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-cyan-500/50 transition-all">
              <div className="h-12 w-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Gerenciamento de Frota</h3>
              <p className="text-slate-400">Controle completo da sua frota com status de bateria e manutenção</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Pronto para começar?</h2>
          <p className="text-lg text-slate-400 mb-8">
            Junte-se a operadores de drones que já confiam na NomadScan para suas operações críticas
          </p>
          <Button
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
            size="lg"
            className="bg-cyan-500 hover:bg-cyan-600 text-white text-lg h-12 px-12"
          >
            Entrar Agora
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-8 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <img src="/manus-storage/nomadscan-logo_900d50e6.png" alt="NomadScan" className="h-6 w-6 object-contain" />
            <span className="text-white font-semibold">NomadScan</span>
          </div>
          <p className="text-slate-400 text-sm">© 2026 NomadScan. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
