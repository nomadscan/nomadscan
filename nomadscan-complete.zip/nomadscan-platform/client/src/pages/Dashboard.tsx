import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: stats, isLoading } = trpc.dashboard.getStats.useQuery();

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const chartData = [
    { name: "Seg", missões: 4, detecções: 2 },
    { name: "Ter", missões: 3, detecções: 1 },
    { name: "Qua", missões: 2, detecções: 4 },
    { name: "Qui", missões: 5, detecções: 3 },
    { name: "Sex", missões: 4, detecções: 2 },
    { name: "Sab", missões: 6, detecções: 5 },
    { name: "Dom", missões: 3, detecções: 1 },
  ];

  const droneStatusData = [
    { name: "Ativo", value: stats?.activeDrones || 0, fill: "#00d4ff" },
    { name: "Offline", value: stats?.offlineDrones || 0, fill: "#64748b" },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400">Bem-vindo, {user?.name}! Aqui está o resumo de suas operações.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-slate-700 bg-slate-800/50">
            <div className="p-6">
              <p className="text-sm text-slate-400">Drones Ativos</p>
              <p className="text-3xl font-bold text-cyan-400">{stats?.activeDrones || 0}</p>
              <p className="text-xs text-slate-500">de {stats?.totalDrones || 0} total</p>
            </div>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <div className="p-6">
              <p className="text-sm text-slate-400">Missões em Andamento</p>
              <p className="text-3xl font-bold text-green-400">{stats?.ongoingMissions || 0}</p>
              <p className="text-xs text-slate-500">de {stats?.totalMissions || 0} total</p>
            </div>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <div className="p-6">
              <p className="text-sm text-slate-400">Missões Concluídas</p>
              <p className="text-3xl font-bold text-blue-400">{stats?.completedMissions || 0}</p>
              <p className="text-xs text-slate-500">nesta semana</p>
            </div>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <div className="p-6">
              <p className="text-sm text-slate-400">Notificações</p>
              <p className="text-3xl font-bold text-red-400">{stats?.unreadNotifications || 0}</p>
              <p className="text-xs text-slate-500">não lidas</p>
            </div>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Activity Chart */}
          <Card className="border-slate-700 bg-slate-800/50 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Atividade da Semana</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
                <Legend />
                <Line type="monotone" dataKey="missões" stroke="#00d4ff" strokeWidth={2} />
                <Line type="monotone" dataKey="detecções" stroke="#22c55e" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Status Chart */}
          <Card className="border-slate-700 bg-slate-800/50 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Status da Frota</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={droneStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {droneStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Recent Detections */}
        {stats?.recentDetections && stats.recentDetections.length > 0 && (
          <Card className="border-slate-700 bg-slate-800/50 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Detecções Recentes</h3>
            <div className="space-y-3">
              {stats.recentDetections.slice(0, 5).map((detection: any) => (
                <div key={detection.id} className="flex items-center justify-between border-b border-slate-700 pb-3 last:border-0">
                  <div>
                    <p className="font-medium text-white capitalize">{detection.detectionType}</p>
                    <p className="text-sm text-slate-400">{detection.description || "Sem descrição"}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-semibold capitalize ${
                      detection.severity === "critical" ? "text-red-400" :
                      detection.severity === "high" ? "text-orange-400" :
                      detection.severity === "medium" ? "text-yellow-400" :
                      "text-green-400"
                    }`}>
                      {detection.severity}
                    </p>
                    <p className="text-xs text-slate-500">{Math.round(parseFloat(detection.confidence) * 100)}% confiança</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
