import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, MapPin } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { useState, useEffect } from "react";

export default function MapPage() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: drones, isLoading } = trpc.drones.list.useQuery();
  const [selectedDrone, setSelectedDrone] = useState<number | null>(null);

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const activeDrones = drones?.filter((d) => d.status === "active") || [];
  const selectedDroneData = drones?.find((d) => d.id === selectedDrone);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Mapa de Drones</h1>
          <p className="text-slate-400">Visualize a localização em tempo real de seus drones</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Map */}
          <div className="lg:col-span-3">
            <Card className="border-slate-700 bg-slate-800/50 overflow-hidden">
              <div className="h-96 md:h-[500px] bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center relative">
                {/* Simulated map view */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-16 w-16 text-cyan-400/30 mx-auto mb-4" />
                    <p className="text-slate-400">Mapa Interativo</p>
                    <p className="text-sm text-slate-500">Selecione um drone para visualizar sua localização</p>
                  </div>
                </div>

                {/* Drone markers */}
                {drones?.map((drone) => (
                  drone.latitude && drone.longitude && (
                    <button
                      key={drone.id}
                      onClick={() => setSelectedDrone(drone.id)}
                      className={`absolute transition-all z-10 ${
                        selectedDrone === drone.id ? "scale-125" : "scale-100 hover:scale-110"
                      }`}
                      style={{
                        left: `${(parseFloat(drone.longitude.toString()) + 46.6333) * 50}px`,
                        top: `${(parseFloat(drone.latitude.toString()) + 23.5505) * 50}px`,
                      }}
                      title={drone.name}
                    >
                      <div className={`w-4 h-4 rounded-full shadow-lg ${
                        drone.status === "active" ? "bg-cyan-400" : "bg-gray-400"
                      }`} />
                    </button>
                  )
                ))}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <Card className="border-slate-700 bg-slate-800/50 p-4">
              <h3 className="mb-4 font-semibold text-white">Drones Ativos</h3>
              <div className="space-y-2">
                {activeDrones.length > 0 ? (
                  activeDrones.map((drone) => (
                    <button
                      key={drone.id}
                      onClick={() => setSelectedDrone(drone.id)}
                      className={`w-full rounded-lg p-3 text-left transition-colors ${
                        selectedDrone === drone.id
                          ? "border border-cyan-400 bg-cyan-500/20"
                          : "border border-slate-700 bg-slate-700/50 hover:bg-slate-700"
                      }`}
                    >
                      <p className="font-medium text-white">{drone.name}</p>
                      <p className="text-xs text-slate-400">{drone.model}</p>
                    </button>
                  ))
                ) : (
                  <p className="text-sm text-slate-400">Nenhum drone ativo</p>
                )}
              </div>
            </Card>

            {/* Selected Drone Details */}
            {selectedDroneData && (
              <Card className="border-slate-700 bg-slate-800/50 p-4">
                <h3 className="mb-4 font-semibold text-white">Detalhes</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="text-slate-400">Nome</p>
                    <p className="font-medium text-white">{selectedDroneData.name}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Modelo</p>
                    <p className="font-medium text-white">{selectedDroneData.model}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Status</p>
                    <p className={`font-medium ${
                      selectedDroneData.status === "active" ? "text-green-400" : "text-red-400"
                    }`}>
                      {selectedDroneData.status === "active" ? "Ativo" : "Offline"}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400">Bateria</p>
                    <div className="mt-1 flex items-center gap-2">
                      <div className="h-2 flex-1 rounded-full bg-slate-700">
                        <div
                          className="h-full rounded-full bg-green-500"
                          style={{ width: `${selectedDroneData.batteryLevel}%` }}
                        />
                      </div>
                      <span className="font-medium text-white">{selectedDroneData.batteryLevel}%</span>
                    </div>
                  </div>
                  {selectedDroneData.latitude && selectedDroneData.longitude && (
                    <div>
                      <p className="text-slate-400">Coordenadas</p>
                      <p className="font-mono text-xs text-white">
                        {parseFloat(selectedDroneData.latitude.toString()).toFixed(6)}, {parseFloat(selectedDroneData.longitude.toString()).toFixed(6)}
                      </p>
                    </div>
                  )}
                  {selectedDroneData.altitude && (
                    <div>
                      <p className="text-slate-400">Altitude</p>
                      <p className="font-medium text-white">{selectedDroneData.altitude}m</p>
                    </div>
                  )}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
