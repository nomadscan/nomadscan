import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, Upload, Download, Trash2, Image, Video, FileText } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function CloudStorage() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: storage, isLoading, refetch } = trpc.storage.list.useQuery();
  const createMutation = trpc.storage.create.useMutation();
  const [isOpen, setIsOpen] = useState(false);
  const [uploading, setUploading] = useState(false);

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      // Simulate file upload to S3
      const fileKey = `${Date.now()}-${file.name}`;
      const fileUrl = `/storage/${fileKey}`;

      await createMutation.mutateAsync({
        fileName: file.name,
        fileKey,
        fileUrl,
        fileType: file.type.startsWith("image") ? "image" : file.type.startsWith("video") ? "video" : "document",
        mimeType: file.type,
        fileSize: file.size,
      });

      toast.success("Arquivo enviado com sucesso!");
      setIsOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao enviar arquivo");
    } finally {
      setUploading(false);
    }
  };

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case "image":
        return <Image className="h-8 w-8 text-cyan-400" />;
      case "video":
        return <Video className="h-8 w-8 text-cyan-400" />;
      default:
        return <FileText className="h-8 w-8 text-cyan-400" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const totalSize = storage?.reduce((sum, item) => sum + (item.fileSize || 0), 0) || 0;
  const imageCount = storage?.filter((s) => s.fileType === "image").length || 0;
  const videoCount = storage?.filter((s) => s.fileType === "video").length || 0;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Armazenamento em Nuvem</h1>
            <p className="text-slate-400">Gerencie suas imagens, vídeos e documentos</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-cyan-500 hover:bg-cyan-600">
                <Upload className="mr-2 h-4 w-4" />
                Enviar Arquivo
              </Button>
            </DialogTrigger>
            <DialogContent className="border-slate-700 bg-slate-800">
              <DialogHeader>
                <DialogTitle className="text-white">Enviar Arquivo</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="rounded-lg border-2 border-dashed border-slate-600 p-8 text-center">
                  <Input
                    type="file"
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <div className="flex flex-col items-center gap-2">
                      <Upload className="h-8 w-8 text-slate-400" />
                      <p className="font-medium text-white">Clique para selecionar</p>
                      <p className="text-sm text-slate-400">ou arraste um arquivo aqui</p>
                    </div>
                  </label>
                </div>
                {uploading && (
                  <p className="text-center text-sm text-slate-400">Enviando...</p>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Statistics */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Total de Arquivos</p>
            <p className="text-2xl font-bold text-cyan-400">{storage?.length || 0}</p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Imagens</p>
            <p className="text-2xl font-bold text-green-400">{imageCount}</p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Vídeos</p>
            <p className="text-2xl font-bold text-blue-400">{videoCount}</p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Espaço Usado</p>
            <p className="text-2xl font-bold text-orange-400">{formatFileSize(totalSize)}</p>
          </Card>
        </div>

        {/* Files Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {storage && storage.length > 0 ? (
            storage.map((file) => (
              <Card key={file.id} className="border-slate-700 bg-slate-800/50 overflow-hidden hover:border-cyan-400/50 transition-colors">
                <div className="aspect-square bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center">
                  {getFileIcon(file.fileType)}
                </div>
                <div className="p-4">
                  <h3 className="mb-2 truncate font-semibold text-white text-sm">{file.fileName}</h3>
                  <p className="mb-3 text-xs text-slate-400">{formatFileSize(file.fileSize || 0)}</p>
                  <p className="mb-3 text-xs text-slate-500">
                    {new Date(file.uploadedAt).toLocaleDateString("pt-BR")}
                  </p>
                  <div className="flex gap-2">
                    <a
                      href={file.fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1"
                    >
                      <Button variant="outline" size="sm" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700">
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                    </a>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-slate-600 text-red-400 hover:bg-red-500/10"
                      onClick={() => toast.info("Exclusão não implementada nesta versão")}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="col-span-full border-slate-700 bg-slate-800/50 p-12 text-center">
              <p className="text-slate-400">Nenhum arquivo enviado ainda. Envie seu primeiro arquivo para começar!</p>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
