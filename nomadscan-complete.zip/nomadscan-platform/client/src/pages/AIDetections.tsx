import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, AlertTriangle, CheckCircle, Filter } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AIDetections() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: detections, isLoading, refetch } = trpc.detections.list.useQuery();
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [filterType, setFilterType] = useState<string>("all");

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const filteredDetections = detections?.filter((d) => {
    const severityMatch = filterSeverity === "all" || d.severity === filterSeverity;
    const typeMatch = filterType === "all" || d.detectionType === filterType;
    return severityMatch && typeMatch;
  }) || [];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      case "high":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30";
      case "medium":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      default:
        return "bg-green-500/20 text-green-400 border-green-500/30";
    }
  };

  const getSeverityLabel = (severity: string) => {
    switch (severity) {
      case "critical":
        return "Crítico";
      case "high":
        return "Alto";
      case "medium":
        return "Médio";
      default:
        return "Baixo";
    }
  };

  const getDetectionTypeLabel = (type: string) => {
    switch (type) {
      case "person":
        return "Pessoa";
      case "vehicle":
        return "Veículo";
      case "fire":
        return "Incêndio";
      case "object":
        return "Objeto";
      default:
        return "Outro";
    }
  };

  const getDetectionTypeIcon = (type: string) => {
    switch (type) {
      case "person":
        return "👤";
      case "vehicle":
        return "🚗";
      case "fire":
        return "🔥";
      case "object":
        return "📦";
      default:
        return "❓";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Detecções por IA</h1>
          <p className="text-slate-400">Visualize todas as detecções automáticas de IA</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 md:flex-row md:items-end">
          <div className="flex-1">
            <label className="text-sm font-medium text-slate-300">Filtrar por Severidade</label>
            <Select value={filterSeverity} onValueChange={setFilterSeverity}>
              <SelectTrigger className="mt-2 border-slate-600 bg-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-700">
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="critical">Crítico</SelectItem>
                <SelectItem value="high">Alto</SelectItem>
                <SelectItem value="medium">Médio</SelectItem>
                <SelectItem value="low">Baixo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <label className="text-sm font-medium text-slate-300">Filtrar por Tipo</label>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="mt-2 border-slate-600 bg-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-700">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="person">Pessoa</SelectItem>
                <SelectItem value="vehicle">Veículo</SelectItem>
                <SelectItem value="fire">Incêndio</SelectItem>
                <SelectItem value="object">Objeto</SelectItem>
                <SelectItem value="other">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Total de Detecções</p>
            <p className="text-2xl font-bold text-cyan-400">{detections?.length || 0}</p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Críticas</p>
            <p className="text-2xl font-bold text-red-400">
              {detections?.filter((d) => d.severity === "critical").length || 0}
            </p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Altas</p>
            <p className="text-2xl font-bold text-orange-400">
              {detections?.filter((d) => d.severity === "high").length || 0}
            </p>
          </Card>
          <Card className="border-slate-700 bg-slate-800/50 p-4">
            <p className="text-sm text-slate-400">Não Lidas</p>
            <p className="text-2xl font-bold text-yellow-400">
              {detections?.filter((d) => !d.acknowledged).length || 0}
            </p>
          </Card>
        </div>

        {/* Detections List */}
        <div className="space-y-4">
          {filteredDetections.length > 0 ? (
            filteredDetections.map((detection) => (
              <Card
                key={detection.id}
                className={`border-2 bg-slate-800/50 p-6 transition-all ${getSeverityColor(detection.severity)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="mb-2 flex items-center gap-3">
                      <span className="text-2xl">
                        {getDetectionTypeIcon(detection.detectionType)}
                      </span>
                      <div>
                        <h3 className="text-lg font-semibold text-white">
                          {getDetectionTypeLabel(detection.detectionType)}
                        </h3>
                        <p className="text-sm text-slate-400">
                          {new Date(detection.createdAt).toLocaleString("pt-BR")}
                        </p>
                      </div>
                    </div>

                    {detection.description && (
                      <p className="mb-3 text-slate-300">{detection.description}</p>
                    )}

                    <div className="flex flex-wrap gap-4 text-sm">
                      <div>
                        <p className="text-slate-400">Confiança</p>
                        <div className="mt-1 flex items-center gap-2">
                          <div className="h-2 w-24 rounded-full bg-slate-600">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-cyan-500"
                              style={{ width: `${Math.round(parseFloat(detection.confidence) * 100)}%` }}
                            />
                          </div>
                          <span className="font-mono text-white">
                            {Math.round(parseFloat(detection.confidence) * 100)}%
                          </span>
                        </div>
                      </div>

                      {detection.latitude && detection.longitude && (
                        <div>
                          <p className="text-slate-400">Localização</p>
                          <p className="font-mono text-white text-xs">
                            {parseFloat(detection.latitude.toString()).toFixed(6)}, {parseFloat(detection.longitude.toString()).toFixed(6)}
                          </p>
                        </div>
                      )}

                      <div>
                        <p className="text-slate-400">Severidade</p>
                        <p className="font-semibold text-white capitalize">
                          {getSeverityLabel(detection.severity)}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="ml-4 flex flex-col gap-2">
                    {detection.acknowledged ? (
                      <div className="flex items-center gap-1 rounded-lg bg-green-500/20 px-3 py-2 text-sm text-green-400">
                        <CheckCircle className="h-4 w-4" />
                        Confirmada
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 rounded-lg bg-yellow-500/20 px-3 py-2 text-sm text-yellow-400">
                        <AlertTriangle className="h-4 w-4" />
                        Pendente
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="border-slate-700 bg-slate-800/50 p-12 text-center">
              <p className="text-slate-400">Nenhuma detecção encontrada com os filtros selecionados</p>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
