import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, Plus, Edit2, Trash2, MapPin, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function Missions() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: missions, isLoading, refetch } = trpc.missions.list.useQuery();
  const { data: drones } = trpc.drones.list.useQuery();
  const createMutation = trpc.missions.create.useMutation();
  const updateMutation = trpc.missions.update.useMutation();
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    droneId: "",
    status: "planned",
  });

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          name: formData.name,
          description: formData.description,
          status: formData.status as any,
        });
        toast.success("Missão atualizada com sucesso!");
      } else {
        await createMutation.mutateAsync({
          droneId: parseInt(formData.droneId),
          name: formData.name,
          description: formData.description,
        });
        toast.success("Missão criada com sucesso!");
      }
      setFormData({ name: "", description: "", droneId: "", status: "planned" });
      setEditingId(null);
      setIsOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao salvar missão");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ongoing":
        return "bg-green-500/20 text-green-400";
      case "completed":
        return "bg-blue-500/20 text-blue-400";
      case "cancelled":
        return "bg-red-500/20 text-red-400";
      default:
        return "bg-yellow-500/20 text-yellow-400";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "ongoing":
        return "Em Andamento";
      case "completed":
        return "Concluída";
      case "cancelled":
        return "Cancelada";
      default:
        return "Planejada";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Missões</h1>
            <p className="text-slate-400">Gerencie todas as suas missões de voo</p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-cyan-500 hover:bg-cyan-600">
                <Plus className="mr-2 h-4 w-4" />
                Nova Missão
              </Button>
            </DialogTrigger>
            <DialogContent className="border-slate-700 bg-slate-800">
              <DialogHeader>
                <DialogTitle className="text-white">
                  {editingId ? "Editar Missão" : "Nova Missão"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-300">Nome da Missão</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Inspeção de linha de transmissão"
                    className="mt-1 border-slate-600 bg-slate-700 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300">Descrição</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Detalhes da missão..."
                    className="mt-1 border-slate-600 bg-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300">Drone</label>
                  <Select value={formData.droneId} onValueChange={(value) => setFormData({ ...formData, droneId: value })}>
                    <SelectTrigger className="mt-1 border-slate-600 bg-slate-700 text-white">
                      <SelectValue placeholder="Selecione um drone" />
                    </SelectTrigger>
                    <SelectContent className="border-slate-600 bg-slate-700">
                      {drones?.map((drone) => (
                        <SelectItem key={drone.id} value={drone.id.toString()}>
                          {drone.name} ({drone.model})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {editingId && (
                  <div>
                    <label className="text-sm font-medium text-slate-300">Status</label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger className="mt-1 border-slate-600 bg-slate-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="border-slate-600 bg-slate-700">
                        <SelectItem value="planned">Planejada</SelectItem>
                        <SelectItem value="ongoing">Em Andamento</SelectItem>
                        <SelectItem value="completed">Concluída</SelectItem>
                        <SelectItem value="cancelled">Cancelada</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <Button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-600">
                  {editingId ? "Atualizar" : "Criar"} Missão
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Missions List */}
        <div className="grid gap-4">
          {missions && missions.length > 0 ? (
            missions.map((mission) => (
              <Card key={mission.id} className="border-slate-700 bg-slate-800/50 p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="mb-2 flex items-center gap-2">
                      <h3 className="text-lg font-semibold text-white">{mission.name}</h3>
                      <span className={`rounded-full px-3 py-1 text-xs font-medium ${getStatusColor(mission.status)}`}>
                        {getStatusLabel(mission.status)}
                      </span>
                    </div>
                    {mission.description && (
                      <p className="mb-3 text-slate-400">{mission.description}</p>
                    )}
                    <div className="flex flex-wrap gap-4 text-sm text-slate-400">
                      {mission.startLatitude && mission.startLongitude && (
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          <span>{mission.startLatitude}, {mission.startLongitude}</span>
                        </div>
                      )}
                      {mission.actualStart && (
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{new Date(mission.actualStart).toLocaleDateString("pt-BR")}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="ml-4 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingId(mission.id);
                        setFormData({
                          name: mission.name,
                          description: mission.description || "",
                          droneId: mission.droneId.toString(),
                          status: mission.status,
                        });
                        setIsOpen(true);
                      }}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="border-slate-700 bg-slate-800/50 p-12 text-center">
              <p className="text-slate-400">Nenhuma missão criada ainda. Crie uma nova missão para começar!</p>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
