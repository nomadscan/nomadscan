import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Loader2, Radio, Gauge, Compass, Zap, Thermometer, Signal } from "lucide-react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Live() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [selectedDroneId, setSelectedDroneId] = useState<string>("");
  const [isRecording, setIsRecording] = useState(false);
  const [simulatedTelemetry, setSimulatedTelemetry] = useState({
    altitude: 120,
    speed: 15.5,
    heading: 45,
    batteryLevel: 85,
    signalStrength: 95,
    temperature: 28.5,
    latitude: -23.5505,
    longitude: -46.6333,
  });

  const { data: drones, isLoading } = trpc.drones.list.useQuery();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/");
    }
  }, [authLoading, user, navigate]);

  // Simulate telemetry updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulatedTelemetry((prev) => ({
        ...prev,
        altitude: Math.max(0, prev.altitude + (Math.random() - 0.5) * 10),
        speed: Math.max(0, prev.speed + (Math.random() - 0.5) * 2),
        heading: (prev.heading + Math.random() * 5) % 360,
        batteryLevel: Math.max(0, prev.batteryLevel - 0.1),
        signalStrength: Math.max(50, Math.min(100, prev.signalStrength + (Math.random() - 0.5) * 5)),
        temperature: prev.temperature + (Math.random() - 0.5) * 0.5,
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  if (authLoading || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const activeDrones = drones?.filter((d) => d.status === "active") || [];
  const selectedDrone = drones?.find((d) => d.id === parseInt(selectedDroneId));

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Transmissão ao Vivo</h1>
          <p className="text-slate-400">Acompanhe a transmissão em tempo real do seu drone</p>
        </div>

        {/* Drone Selector */}
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="text-sm font-medium text-slate-300">Selecione um Drone</label>
            <Select value={selectedDroneId} onValueChange={setSelectedDroneId}>
              <SelectTrigger className="mt-2 border-slate-600 bg-slate-700 text-white">
                <SelectValue placeholder="Escolha um drone ativo" />
              </SelectTrigger>
              <SelectContent className="border-slate-600 bg-slate-700">
                {activeDrones.map((drone) => (
                  <SelectItem key={drone.id} value={drone.id.toString()}>
                    {drone.name} ({drone.model})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end gap-2">
            <Button
              onClick={() => setIsRecording(!isRecording)}
              className={isRecording ? "bg-red-500 hover:bg-red-600" : "bg-cyan-500 hover:bg-cyan-600"}
            >
              <Radio className="mr-2 h-4 w-4" />
              {isRecording ? "Parando..." : "Iniciar Gravação"}
            </Button>
          </div>
        </div>

        {selectedDrone && (
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Video Player */}
            <div className="lg:col-span-2">
              <Card className="border-slate-700 bg-slate-800/50 overflow-hidden">
                <div className="relative aspect-video bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
                  {/* Simulated video feed */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="mb-4 h-32 w-32 rounded-full border-4 border-cyan-400/30 animate-pulse" />
                    <p className="text-slate-400">Transmissão ao Vivo</p>
                    <p className="text-sm text-slate-500">{selectedDrone.name}</p>
                  </div>

                  {/* Recording indicator */}
                  {isRecording && (
                    <div className="absolute top-4 left-4 flex items-center gap-2 rounded-lg bg-red-500/20 px-3 py-2 border border-red-500/50">
                      <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-sm font-medium text-red-400">GRAVANDO</span>
                    </div>
                  )}

                  {/* Status indicator */}
                  <div className="absolute top-4 right-4 flex items-center gap-2 rounded-lg bg-green-500/20 px-3 py-2 border border-green-500/50">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-sm font-medium text-green-400">AO VIVO</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Telemetry Panel */}
            <div className="space-y-4">
              <Card className="border-slate-700 bg-slate-800/50 p-4">
                <h3 className="mb-4 font-semibold text-white">Telemetria</h3>
                <div className="space-y-3">
                  {/* Altitude */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Zap className="h-4 w-4" />
                        <span className="text-sm">Altitude</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.altitude.toFixed(1)}m</span>
                    </div>
                  </div>

                  {/* Speed */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Gauge className="h-4 w-4" />
                        <span className="text-sm">Velocidade</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.speed.toFixed(1)}m/s</span>
                    </div>
                  </div>

                  {/* Heading */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Compass className="h-4 w-4" />
                        <span className="text-sm">Rumo</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.heading.toFixed(0)}°</span>
                    </div>
                  </div>

                  {/* Battery */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Zap className="h-4 w-4" />
                        <span className="text-sm">Bateria</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.batteryLevel.toFixed(0)}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-600">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-green-400 to-green-500 transition-all"
                        style={{ width: `${simulatedTelemetry.batteryLevel}%` }}
                      />
                    </div>
                  </div>

                  {/* Signal */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Signal className="h-4 w-4" />
                        <span className="text-sm">Sinal</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.signalStrength.toFixed(0)}%</span>
                    </div>
                  </div>

                  {/* Temperature */}
                  <div className="rounded-lg bg-slate-700/50 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Thermometer className="h-4 w-4" />
                        <span className="text-sm">Temperatura</span>
                      </div>
                      <span className="font-mono text-cyan-400">{simulatedTelemetry.temperature.toFixed(1)}°C</span>
                    </div>
                  </div>
                </div>
              </Card>

              {/* GPS Info */}
              <Card className="border-slate-700 bg-slate-800/50 p-4">
                <h3 className="mb-3 font-semibold text-white text-sm">GPS</h3>
                <div className="space-y-2 text-xs">
                  <p className="text-slate-400">
                    Lat: <span className="font-mono text-white">{simulatedTelemetry.latitude.toFixed(6)}</span>
                  </p>
                  <p className="text-slate-400">
                    Lon: <span className="font-mono text-white">{simulatedTelemetry.longitude.toFixed(6)}</span>
                  </p>
                </div>
              </Card>
            </div>
          </div>
        )}

        {!selectedDrone && (
          <Card className="border-slate-700 bg-slate-800/50 p-12 text-center">
            <p className="text-slate-400">Selecione um drone ativo para iniciar a transmissão ao vivo</p>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
