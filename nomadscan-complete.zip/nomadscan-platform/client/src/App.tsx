import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Missions from "./pages/Missions";
import Drones from "./pages/Drones";
import MapPage from "./pages/MapPage";
import Live from "./pages/Live";
import AIDetections from "./pages/AIDetections";
import CloudStorage from "./pages/CloudStorage";
import Profile from "./pages/Profile";
import Reports from "./pages/Reports";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/missions"} component={Missions} />
      <Route path={"/drones"} component={Drones} />
      <Route path={"/map"} component={MapPage} />
      <Route path={"/live"} component={Live} />
      <Route path={"/detections"} component={AIDetections} />
      <Route path={"/storage"} component={CloudStorage} />
      <Route path={"/reports"} component={Reports} />
      <Route path={"/profile"} component={Profile} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
