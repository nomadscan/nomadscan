CREATE TABLE `aiDetections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`missionId` int NOT NULL,
	`droneId` int NOT NULL,
	`detectionType` enum('object','person','vehicle','fire','other') NOT NULL,
	`confidence` decimal(3,2) NOT NULL,
	`latitude` decimal(10,8),
	`longitude` decimal(11,8),
	`imageUrl` varchar(512),
	`description` text,
	`severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`acknowledged` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiDetections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cloudStorage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`missionId` int,
	`droneId` int,
	`fileName` varchar(255) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` varchar(512) NOT NULL,
	`fileType` varchar(50) NOT NULL,
	`mimeType` varchar(100) NOT NULL,
	`fileSize` int,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cloudStorage_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `drones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`model` varchar(255) NOT NULL,
	`serialNumber` varchar(255) NOT NULL,
	`status` enum('active','inactive','maintenance','offline') NOT NULL DEFAULT 'offline',
	`batteryLevel` int NOT NULL DEFAULT 0,
	`latitude` decimal(10,8) DEFAULT '0',
	`longitude` decimal(11,8) DEFAULT '0',
	`altitude` int DEFAULT 0,
	`lastLocationUpdate` timestamp,
	`maintenanceStatus` varchar(255) DEFAULT 'good',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drones_id` PRIMARY KEY(`id`),
	CONSTRAINT `drones_serialNumber_unique` UNIQUE(`serialNumber`)
);
--> statement-breakpoint
CREATE TABLE `missionReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`missionId` int NOT NULL,
	`reportContent` text NOT NULL,
	`summary` text,
	`detectionsSummary` text,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `missionReports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `missions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`droneId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`status` enum('planned','ongoing','completed','cancelled') NOT NULL DEFAULT 'planned',
	`startLatitude` decimal(10,8),
	`startLongitude` decimal(11,8),
	`endLatitude` decimal(10,8),
	`endLongitude` decimal(11,8),
	`scheduledStart` timestamp,
	`actualStart` timestamp,
	`actualEnd` timestamp,
	`duration` int,
	`flightPath` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `missions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('mission_completed','ai_detection','battery_critical','drone_offline','system') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`relatedEntityId` int,
	`read` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `telemetry` (
	`id` int AUTO_INCREMENT NOT NULL,
	`droneId` int NOT NULL,
	`missionId` int,
	`latitude` decimal(10,8) NOT NULL,
	`longitude` decimal(11,8) NOT NULL,
	`altitude` int NOT NULL,
	`speed` decimal(5,2) NOT NULL,
	`heading` int,
	`batteryLevel` int NOT NULL,
	`signalStrength` int,
	`temperature` decimal(5,2),
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telemetry_id` PRIMARY KEY(`id`)
);
