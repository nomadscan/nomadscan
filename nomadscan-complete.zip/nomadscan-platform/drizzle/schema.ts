import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Drones table for fleet management
 */
export const drones = mysqlTable("drones", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  serialNumber: varchar("serialNumber", { length: 255 }).notNull().unique(),
  status: mysqlEnum("status", ["active", "inactive", "maintenance", "offline"]).default("offline").notNull(),
  batteryLevel: int("batteryLevel").default(0).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).default("0"),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).default("0"),
  altitude: int("altitude").default(0),
  lastLocationUpdate: timestamp("lastLocationUpdate"),
  maintenanceStatus: varchar("maintenanceStatus", { length: 255 }).default("good"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Drone = typeof drones.$inferSelect;
export type InsertDrone = typeof drones.$inferInsert;

/**
 * Missions table for mission management
 */
export const missions = mysqlTable("missions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  droneId: int("droneId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["planned", "ongoing", "completed", "cancelled"]).default("planned").notNull(),
  startLatitude: decimal("startLatitude", { precision: 10, scale: 8 }),
  startLongitude: decimal("startLongitude", { precision: 11, scale: 8 }),
  endLatitude: decimal("endLatitude", { precision: 10, scale: 8 }),
  endLongitude: decimal("endLongitude", { precision: 11, scale: 8 }),
  scheduledStart: timestamp("scheduledStart"),
  actualStart: timestamp("actualStart"),
  actualEnd: timestamp("actualEnd"),
  duration: int("duration"), // in seconds
  flightPath: json("flightPath"), // Array of coordinates
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Mission = typeof missions.$inferSelect;
export type InsertMission = typeof missions.$inferInsert;

/**
 * AI Detections table for AI module
 */
export const aiDetections = mysqlTable("aiDetections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  missionId: int("missionId").notNull(),
  droneId: int("droneId").notNull(),
  detectionType: mysqlEnum("detectionType", ["object", "person", "vehicle", "fire", "other"]).notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }).notNull(), // 0.00 to 1.00
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  imageUrl: varchar("imageUrl", { length: 512 }),
  description: text("description"),
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  acknowledged: boolean("acknowledged").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AiDetection = typeof aiDetections.$inferSelect;
export type InsertAiDetection = typeof aiDetections.$inferInsert;

/**
 * Cloud Storage table for media management
 */
export const cloudStorage = mysqlTable("cloudStorage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  missionId: int("missionId"),
  droneId: int("droneId"),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  fileUrl: varchar("fileUrl", { length: 512 }).notNull(),
  fileType: varchar("fileType", { length: 50 }).notNull(), // image, video, etc
  mimeType: varchar("mimeType", { length: 100 }).notNull(),
  fileSize: int("fileSize"), // in bytes
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type CloudStorage = typeof cloudStorage.$inferSelect;
export type InsertCloudStorage = typeof cloudStorage.$inferInsert;

/**
 * Notifications table
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["mission_completed", "ai_detection", "battery_critical", "drone_offline", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  relatedEntityId: int("relatedEntityId"), // mission, drone, or detection ID
  read: boolean("read").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Mission Reports table for LLM-generated reports
 */
export const missionReports = mysqlTable("missionReports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  missionId: int("missionId").notNull(),
  reportContent: text("reportContent").notNull(),
  summary: text("summary"),
  detectionsSummary: text("detectionsSummary"),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
});

export type MissionReport = typeof missionReports.$inferSelect;
export type InsertMissionReport = typeof missionReports.$inferInsert;

/**
 * Telemetry data for real-time drone information
 */
export const telemetry = mysqlTable("telemetry", {
  id: int("id").autoincrement().primaryKey(),
  droneId: int("droneId").notNull(),
  missionId: int("missionId"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  altitude: int("altitude").notNull(),
  speed: decimal("speed", { precision: 5, scale: 2 }).notNull(), // m/s
  heading: int("heading"), // degrees
  batteryLevel: int("batteryLevel").notNull(),
  signalStrength: int("signalStrength"), // 0-100
  temperature: decimal("temperature", { precision: 5, scale: 2 }),
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
});

export type Telemetry = typeof telemetry.$inferSelect;
export type InsertTelemetry = typeof telemetry.$inferInsert;
