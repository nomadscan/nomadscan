import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { llmRouter } from "./routers-llm";

export const appRouter = router({
  system: systemRouter,
  llm: llmRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Dashboard
  dashboard: router({
    getStats: protectedProcedure.query(async ({ ctx }) => {
      const stats = await db.getDashboardStats(ctx.user.id);
      return stats;
    }),
  }),

  // Drones management
  drones: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getDronesByUserId(ctx.user.id);
    }),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const drone = await db.getDroneById(input.id);
      if (!drone) throw new TRPCError({ code: "NOT_FOUND", message: "Drone not found" });
      return drone;
    }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          model: z.string(),
          serialNumber: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.createDrone({
          userId: ctx.user.id,
          name: input.name,
          model: input.model,
          serialNumber: input.serialNumber,
          status: "offline",
          batteryLevel: 0,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          status: z.enum(["active", "inactive", "maintenance", "offline"]).optional(),
          batteryLevel: z.number().optional(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          altitude: z.number().optional(),
          maintenanceStatus: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const drone = await db.getDroneById(input.id);
        if (!drone) throw new TRPCError({ code: "NOT_FOUND", message: "Drone not found" });

        const updates: Record<string, any> = {};
        if (input.name !== undefined) updates.name = input.name;
        if (input.status !== undefined) updates.status = input.status;
        if (input.batteryLevel !== undefined) updates.batteryLevel = input.batteryLevel;
        if (input.latitude !== undefined) updates.latitude = input.latitude;
        if (input.longitude !== undefined) updates.longitude = input.longitude;
        if (input.altitude !== undefined) updates.altitude = input.altitude;
        if (input.maintenanceStatus !== undefined) updates.maintenanceStatus = input.maintenanceStatus;
        updates.lastLocationUpdate = new Date();

        return db.updateDrone(input.id, updates);
      }),
  }),

  // Missions management
  missions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getMissionsByUserId(ctx.user.id);
    }),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const mission = await db.getMissionById(input.id);
      if (!mission) throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
      return mission;
    }),

    create: protectedProcedure
      .input(
        z.object({
          droneId: z.number(),
          name: z.string(),
          description: z.string().optional(),
          startLatitude: z.string().optional(),
          startLongitude: z.string().optional(),
          endLatitude: z.string().optional(),
          endLongitude: z.string().optional(),
          scheduledStart: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.createMission({
          userId: ctx.user.id,
          droneId: input.droneId,
          name: input.name,
          description: input.description,
          status: "planned",
          startLatitude: input.startLatitude,
          startLongitude: input.startLongitude,
          endLatitude: input.endLatitude,
          endLongitude: input.endLongitude,
          scheduledStart: input.scheduledStart,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["planned", "ongoing", "completed", "cancelled"]).optional(),
          flightPath: z.any().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const mission = await db.getMissionById(input.id);
        if (!mission) throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });

        const updates: Record<string, any> = {};
        if (input.name !== undefined) updates.name = input.name;
        if (input.description !== undefined) updates.description = input.description;
        if (input.status !== undefined) {
          updates.status = input.status;
          if (input.status === "ongoing" && !mission.actualStart) {
            updates.actualStart = new Date();
          }
          if (input.status === "completed" && !mission.actualEnd) {
            updates.actualEnd = new Date();
          }
        }
        if (input.flightPath !== undefined) updates.flightPath = input.flightPath;

        return db.updateMission(input.id, updates);
      }),
  }),

  // AI Detections
  detections: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getDetectionsByUserId(ctx.user.id);
    }),

    getByMission: protectedProcedure.input(z.object({ missionId: z.number() })).query(async ({ input }) => {
      return db.getDetectionsByMissionId(input.missionId);
    }),

    create: protectedProcedure
      .input(
        z.object({
          missionId: z.number(),
          droneId: z.number(),
          detectionType: z.enum(["object", "person", "vehicle", "fire", "other"]),
          confidence: z.number().min(0).max(1),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          imageUrl: z.string().optional(),
          description: z.string().optional(),
          severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.createDetection({
          userId: ctx.user.id,
          missionId: input.missionId,
          droneId: input.droneId,
          detectionType: input.detectionType,
          confidence: input.confidence.toString(),
          latitude: input.latitude,
          longitude: input.longitude,
          imageUrl: input.imageUrl,
          description: input.description,
          severity: input.severity || "medium",
        });
      }),
  }),

  // Cloud Storage
  storage: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getStorageByUserId(ctx.user.id);
    }),

    getByMission: protectedProcedure.input(z.object({ missionId: z.number() })).query(async ({ input }) => {
      return db.getStorageByMissionId(input.missionId);
    }),

    create: protectedProcedure
      .input(
        z.object({
          fileName: z.string(),
          fileKey: z.string(),
          fileUrl: z.string(),
          fileType: z.string(),
          mimeType: z.string(),
          fileSize: z.number().optional(),
          missionId: z.number().optional(),
          droneId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.createStorageEntry({
          userId: ctx.user.id,
          fileName: input.fileName,
          fileKey: input.fileKey,
          fileUrl: input.fileUrl,
          fileType: input.fileType,
          mimeType: input.mimeType,
          fileSize: input.fileSize,
          missionId: input.missionId,
          droneId: input.droneId,
        });
      }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getNotificationsByUserId(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),
  }),

  // Telemetry
  telemetry: router({
    create: protectedProcedure
      .input(
        z.object({
          droneId: z.number(),
          missionId: z.number().optional(),
          latitude: z.string(),
          longitude: z.string(),
          altitude: z.number(),
          speed: z.number(),
          heading: z.number().optional(),
          batteryLevel: z.number(),
          signalStrength: z.number().optional(),
          temperature: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return db.createTelemetryEntry({
          droneId: input.droneId,
          missionId: input.missionId,
          latitude: input.latitude,
          longitude: input.longitude,
          altitude: input.altitude,
          speed: input.speed.toString(),
          heading: input.heading,
          batteryLevel: input.batteryLevel,
          signalStrength: input.signalStrength,
          temperature: input.temperature?.toString(),
        });
      }),

    getLatest: protectedProcedure.input(z.object({ droneId: z.number() })).query(async ({ input }) => {
      return db.getLatestTelemetryByDroneId(input.droneId);
    }),
  }),

  // Mission Reports
  reports: router({
    getByMission: protectedProcedure.input(z.object({ missionId: z.number() })).query(async ({ input }) => {
      return db.getMissionReportByMissionId(input.missionId);
    }),

    create: protectedProcedure
      .input(
        z.object({
          missionId: z.number(),
          reportContent: z.string(),
          summary: z.string().optional(),
          detectionsSummary: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return db.createMissionReport({
          userId: ctx.user.id,
          missionId: input.missionId,
          reportContent: input.reportContent,
          summary: input.summary,
          detectionsSummary: input.detectionsSummary,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
