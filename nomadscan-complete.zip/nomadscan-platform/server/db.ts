import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  drones,
  missions,
  aiDetections,
  cloudStorage,
  notifications,
  telemetry,
  missionReports,
  type Drone,
  type Mission,
  type AiDetection,
  type CloudStorage,
  type Notification,
  type Telemetry,
  type MissionReport,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Drone queries
export async function getDronesByUserId(userId: number): Promise<Drone[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(drones).where(eq(drones.userId, userId));
}

export async function getDroneById(droneId: number): Promise<Drone | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(drones).where(eq(drones.id, droneId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDrone(drone: typeof drones.$inferInsert): Promise<Drone> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(drones).values(drone);
  const id = result[0].insertId as number;
  const created = await getDroneById(id);
  if (!created) throw new Error("Failed to create drone");
  return created;
}

export async function updateDrone(droneId: number, updates: Partial<typeof drones.$inferInsert>): Promise<Drone> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(drones).set(updates).where(eq(drones.id, droneId));
  const updated = await getDroneById(droneId);
  if (!updated) throw new Error("Failed to update drone");
  return updated;
}

// Mission queries
export async function getMissionsByUserId(userId: number): Promise<Mission[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(missions)
    .where(eq(missions.userId, userId))
    .orderBy(desc(missions.createdAt));
}

export async function getMissionById(missionId: number): Promise<Mission | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(missions).where(eq(missions.id, missionId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createMission(mission: typeof missions.$inferInsert): Promise<Mission> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(missions).values(mission);
  const id = result[0].insertId as number;
  const created = await getMissionById(id);
  if (!created) throw new Error("Failed to create mission");
  return created;
}

export async function updateMission(missionId: number, updates: Partial<typeof missions.$inferInsert>): Promise<Mission> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(missions).set(updates).where(eq(missions.id, missionId));
  const updated = await getMissionById(missionId);
  if (!updated) throw new Error("Failed to update mission");
  return updated;
}

// AI Detection queries
export async function getDetectionsByMissionId(missionId: number): Promise<AiDetection[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(aiDetections)
    .where(eq(aiDetections.missionId, missionId))
    .orderBy(desc(aiDetections.createdAt));
}

export async function getDetectionsByUserId(userId: number): Promise<AiDetection[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(aiDetections)
    .where(eq(aiDetections.userId, userId))
    .orderBy(desc(aiDetections.createdAt));
}

export async function createDetection(detection: typeof aiDetections.$inferInsert): Promise<AiDetection> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(aiDetections).values(detection);
  const id = result[0].insertId as number;
  const created = await db.select().from(aiDetections).where(eq(aiDetections.id, id)).limit(1);
  if (created.length === 0) throw new Error("Failed to create detection");
  return created[0];
}

// Cloud Storage queries
export async function getStorageByUserId(userId: number): Promise<CloudStorage[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cloudStorage)
    .where(eq(cloudStorage.userId, userId))
    .orderBy(desc(cloudStorage.uploadedAt));
}

export async function getStorageByMissionId(missionId: number): Promise<CloudStorage[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(cloudStorage)
    .where(eq(cloudStorage.missionId, missionId))
    .orderBy(desc(cloudStorage.uploadedAt));
}

export async function createStorageEntry(entry: typeof cloudStorage.$inferInsert): Promise<CloudStorage> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(cloudStorage).values(entry);
  const id = result[0].insertId as number;
  const created = await db.select().from(cloudStorage).where(eq(cloudStorage.id, id)).limit(1);
  if (created.length === 0) throw new Error("Failed to create storage entry");
  return created[0];
}

// Notification queries
export async function getNotificationsByUserId(userId: number): Promise<Notification[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function createNotification(notification: typeof notifications.$inferInsert): Promise<Notification> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(notifications).values(notification);
  const id = result[0].insertId as number;
  const created = await db.select().from(notifications).where(eq(notifications.id, id)).limit(1);
  if (created.length === 0) throw new Error("Failed to create notification");
  return created[0];
}

export async function markNotificationAsRead(notificationId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set({ read: true }).where(eq(notifications.id, notificationId));
}

// Telemetry queries
export async function createTelemetryEntry(entry: typeof telemetry.$inferInsert): Promise<Telemetry> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(telemetry).values(entry);
  const id = result[0].insertId as number;
  const created = await db.select().from(telemetry).where(eq(telemetry.id, id)).limit(1);
  if (created.length === 0) throw new Error("Failed to create telemetry entry");
  return created[0];
}

export async function getLatestTelemetryByDroneId(droneId: number): Promise<Telemetry | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(telemetry)
    .where(eq(telemetry.droneId, droneId))
    .orderBy(desc(telemetry.recordedAt))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Mission Report queries
export async function getMissionReportByMissionId(missionId: number): Promise<MissionReport | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(missionReports)
    .where(eq(missionReports.missionId, missionId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createMissionReport(report: typeof missionReports.$inferInsert): Promise<MissionReport> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(missionReports).values(report);
  const id = result[0].insertId as number;
  const created = await db.select().from(missionReports).where(eq(missionReports.id, id)).limit(1);
  if (created.length === 0) throw new Error("Failed to create mission report");
  return created[0];
}

// Dashboard statistics
export async function getDashboardStats(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const userDrones = await db.select().from(drones).where(eq(drones.userId, userId));
  const activeDrones = userDrones.filter((d) => d.status === "active").length;
  const offlineDrones = userDrones.filter((d) => d.status === "offline").length;

  const userMissions = await db.select().from(missions).where(eq(missions.userId, userId));
  const ongoingMissions = userMissions.filter((m) => m.status === "ongoing").length;
  const completedMissions = userMissions.filter((m) => m.status === "completed").length;

  const recentDetections = await db
    .select()
    .from(aiDetections)
    .where(eq(aiDetections.userId, userId))
    .orderBy(desc(aiDetections.createdAt))
    .limit(5);

  const unreadNotifications = await db
    .select()
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.read, false)));

  return {
    activeDrones,
    offlineDrones,
    totalDrones: userDrones.length,
    ongoingMissions,
    completedMissions,
    totalMissions: userMissions.length,
    recentDetections,
    unreadNotifications: unreadNotifications.length,
  };
}
