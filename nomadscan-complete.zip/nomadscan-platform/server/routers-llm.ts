import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import { TRPCError } from "@trpc/server";

export const llmRouter = router({
  // Generate mission report using LLM
  generateMissionReport: protectedProcedure
    .input(z.object({ missionId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      try {
        const mission = await db.getMissionById(input.missionId);
        if (!mission) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
        }

        const detections = await db.getDetectionsByMissionId(input.missionId);
        const detectionsSummary = detections
          .map((d) => `- ${d.detectionType}: ${d.description} (confiança: ${Math.round(parseFloat(d.confidence) * 100)}%)`)
          .join("\n");

        const prompt = `Gere um relatório profissional de missão de drone com as seguintes informações:

Missão: ${mission.name}
Descrição: ${mission.description || "N/A"}
Status: ${mission.status}
Data de Início: ${mission.actualStart ? new Date(mission.actualStart).toLocaleString("pt-BR") : "Não iniciada"}
Data de Término: ${mission.actualEnd ? new Date(mission.actualEnd).toLocaleString("pt-BR") : "Em andamento"}

Detecções Realizadas:
${detectionsSummary || "Nenhuma detecção"}

Por favor, forneça:
1. Resumo executivo
2. Análise das detecções
3. Recomendações
4. Conclusões`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Você é um especialista em análise de operações com drones. Gere relatórios profissionais e detalhados.",
            },
            { role: "user", content: prompt },
          ],
        });

        const content = response.choices[0]?.message?.content;
        const reportContent = typeof content === "string" ? content : "";

        // Extract summary (first paragraph)
        const summary = reportContent.split("\n\n")[0] || reportContent.slice(0, 200);

        // Create and store report
        const report = await db.createMissionReport({
          userId: ctx.user.id,
          missionId: input.missionId,
          reportContent,
          summary,
          detectionsSummary: detectionsSummary || "Nenhuma detecção",
        });

        return report;
      } catch (error) {
        console.error("Error generating report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao gerar relatório",
        });
      }
    }),

  // Summarize detections using LLM
  summarizeDetections: protectedProcedure
    .input(z.object({ missionId: z.number() }))
    .query(async ({ input }) => {
      try {
        const detections = await db.getDetectionsByMissionId(input.missionId);

        if (detections.length === 0) {
          return { summary: "Nenhuma detecção realizada nesta missão." };
        }

        const detectionsList = detections
          .map((d) => `- ${d.detectionType}: ${d.description} (severidade: ${d.severity}, confiança: ${Math.round(parseFloat(d.confidence) * 100)}%)`)
          .join("\n");

        const prompt = `Resuma as seguintes detecções de IA de forma concisa e profissional:

${detectionsList}

Forneça um resumo em 2-3 frases destacando os pontos principais e recomendações.`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "Você é um especialista em análise de detecções por IA. Resuma informações de forma clara e concisa.",
            },
            { role: "user", content: prompt },
          ],
        });

        const content = response.choices[0]?.message?.content;
        const summary = typeof content === "string" ? content : "Não foi possível gerar resumo";

        return { summary };
      } catch (error) {
        console.error("Error summarizing detections:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao resumir detecções",
        });
      }
    }),

  // Ask questions about drone data
  askAboutDroneData: protectedProcedure
    .input(
      z.object({
        missionId: z.number(),
        question: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const mission = await db.getMissionById(input.missionId);
        if (!mission) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Mission not found" });
        }

        const detections = await db.getDetectionsByMissionId(input.missionId);
        const detectionsList = detections
          .map((d) => `- ${d.detectionType}: ${d.description} (confiança: ${Math.round(parseFloat(d.confidence) * 100)}%)`)
          .join("\n");

        const context = `Missão: ${mission.name}
Descrição: ${mission.description || "N/A"}
Status: ${mission.status}
Detecções: ${detectionsList || "Nenhuma"}`;

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `Você é um assistente especializado em operações com drones. Responda perguntas com base nos dados da missão fornecidos. Contexto da missão:\n${context}`,
            },
            { role: "user", content: input.question },
          ],
        });

        const content = response.choices[0]?.message?.content;
        const answer = typeof content === "string" ? content : "Não foi possível gerar resposta";

        return { answer };
      } catch (error) {
        console.error("Error answering question:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao responder pergunta",
        });
      }
    }),
});

export type LLMRouter = typeof llmRouter;
