# NomadScan - Plataforma de Monitoramento de Drones com IA

![NomadScan Logo](./client/public/logo.png)

**NomadScan** é uma plataforma web completa e profissional para monitoramento, gestão e operação de frotas de drones com inteligência artificial integrada. Desenvolvida com tecnologias modernas, oferece recursos em tempo real para operadores de drones.

## 🚀 Funcionalidades Principais

- **Dashboard em Tempo Real**: Métricas de drones ativos, missões em andamento, alertas e status da frota
- **Gerenciamento de Missões**: Criar, editar, acompanhar e arquivar missões com status completo
- **Frota de Drones**: Cadastro, monitoramento de bateria, localização e histórico de manutenção
- **Mapa Interativo**: Visualização em tempo real da posição dos drones e trajetórias de voo
- **Transmissão ao Vivo**: Player de vídeo com dados de telemetria em tempo real (altitude, velocidade, bateria, etc)
- **Detecção por IA**: Identificação automática de objetos, pessoas e veículos com nível de confiança
- **Armazenamento em Nuvem**: Upload e gerenciamento de imagens e vídeos via S3
- **Relatórios Automáticos**: Geração de relatórios profissionais com IA baseado em dados de missões
- **Autenticação OAuth**: Login seguro via Manus OAuth
- **Notificações**: Alertas automáticos para eventos críticos

## 🛠️ Stack Tecnológico

### Frontend
- **React 19** - Biblioteca UI moderna
- **TypeScript** - Type safety
- **Tailwind CSS 4** - Estilização responsiva
- **shadcn/ui** - Componentes de UI profissionais
- **Wouter** - Roteamento leve
- **Recharts** - Gráficos e visualizações
- **Framer Motion** - Animações suaves

### Backend
- **Express 4** - Framework web rápido
- **tRPC 11** - RPC type-safe
- **Node.js** - Runtime JavaScript

### Banco de Dados
- **MySQL/TiDB** - Banco de dados relacional
- **Drizzle ORM** - ORM type-safe

### Integrações
- **Manus OAuth** - Autenticação
- **AWS S3** - Armazenamento de arquivos
- **Google Maps** - Mapa interativo
- **LLM API** - Geração de relatórios com IA

## 📋 Pré-requisitos

- Node.js 22.x ou superior
- pnpm 10.x ou superior
- MySQL/TiDB database
- Conta Manus para OAuth

## 🔧 Instalação Local

### 1. Clone o repositório

```bash
git clone https://github.com/seu-usuario/nomadscan-platform.git
cd nomadscan-platform
```

### 2. Instale as dependências

```bash
pnpm install
```

### 3. Configure as variáveis de ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
# Database
DATABASE_URL=mysql://user:password@localhost:3306/nomadscan

# Authentication
JWT_SECRET=seu-secret-jwt-aleatorio
VITE_APP_ID=seu-app-id-manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/oauth

# Manus APIs
BUILT_IN_FORGE_API_URL=https://forge.manus.im
BUILT_IN_FORGE_API_KEY=sua-chave-api
VITE_FRONTEND_FORGE_API_KEY=sua-chave-frontend
VITE_FRONTEND_FORGE_API_URL=https://forge.manus.im

# Owner Info
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu-open-id
```

### 4. Execute as migrações do banco de dados

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

### 5. Inicie o servidor de desenvolvimento

```bash
pnpm run dev
```

O servidor estará disponível em `http://localhost:3000`

## 🚀 Deploy

### Deploy no Vercel

#### 1. Prepare o repositório

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

#### 2. Conecte ao Vercel

1. Acesse [vercel.com](https://vercel.com)
2. Clique em "New Project"
3. Selecione seu repositório GitHub
4. Configure as variáveis de ambiente:

```
DATABASE_URL
JWT_SECRET
VITE_APP_ID
OAUTH_SERVER_URL
VITE_OAUTH_PORTAL_URL
BUILT_IN_FORGE_API_URL
BUILT_IN_FORGE_API_KEY
VITE_FRONTEND_FORGE_API_KEY
VITE_FRONTEND_FORGE_API_URL
OWNER_NAME
OWNER_OPEN_ID
```

5. Clique em "Deploy"

#### 3. Configure o domínio customizado (opcional)

1. Na dashboard do Vercel, vá para "Settings" > "Domains"
2. Adicione seu domínio customizado
3. Configure os registros DNS conforme instruído

### Deploy Manual

#### Build para produção

```bash
pnpm run build
```

#### Inicie o servidor de produção

```bash
pnpm run start
```

## 📁 Estrutura do Projeto

```
nomadscan-platform/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas da aplicação
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── hooks/         # Custom hooks
│   │   ├── contexts/      # React contexts
│   │   ├── lib/           # Utilitários
│   │   └── index.css      # Estilos globais
│   └── public/            # Arquivos estáticos
├── server/                # Backend Express
│   ├── routers.ts         # Procedimentos tRPC
│   ├── db.ts              # Funções de banco de dados
│   └── _core/             # Configuração interna
├── drizzle/               # Schema e migrações
├── shared/                # Código compartilhado
├── storage/               # Helpers de S3
├── references/            # Documentação de integrações
└── package.json
```

## 🔐 Segurança

- **Autenticação**: Manus OAuth com JWT
- **Autorização**: Role-based access control (admin/user)
- **Variáveis de Ambiente**: Nunca commite `.env` files
- **HTTPS**: Sempre use HTTPS em produção
- **CORS**: Configurado para aceitar apenas domínios autorizados

## 📊 Banco de Dados

### Tabelas Principais

- **users** - Usuários autenticados
- **drones** - Frota de drones
- **missions** - Missões de voo
- **ai_detections** - Detecções por IA
- **cloud_storage** - Arquivos armazenados
- **notifications** - Notificações do sistema
- **mission_reports** - Relatórios gerados

## 🧪 Testes

### Executar testes

```bash
pnpm test
```

### Cobertura de testes

```bash
pnpm test:coverage
```

## 📝 Logging

Os logs estão disponíveis em `.manus-logs/`:

- `devserver.log` - Logs do servidor
- `browserConsole.log` - Logs do navegador
- `networkRequests.log` - Requisições HTTP
- `sessionReplay.log` - Eventos de interação

## 🐛 Troubleshooting

### Erro: "Database connection failed"

Verifique se o MySQL está rodando e se a `DATABASE_URL` está correta.

### Erro: "OAuth callback failed"

Confirme que `VITE_APP_ID` e `OAUTH_SERVER_URL` estão corretos.

### Erro: "S3 upload failed"

Verifique as credenciais de S3 e permissões do bucket.

## 📚 Documentação Adicional

- [Integração com LLM](./references/llm-integration.md)
- [Integração com Google Maps](./references/maps-integration.md)
- [Armazenamento em S3](./references/file-storage.md)
- [Transcrição de Voz](./references/voice-transcription.md)
- [Geração de Imagens](./references/image-generation.md)

## 🤝 Contribuindo

1. Fork o repositório
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 📧 Suporte

Para suporte, envie um email para support@nomadscan.com ou abra uma issue no GitHub.

## 🎯 Roadmap

- [ ] Integração com APIs reais de drones
- [ ] WebSocket para atualizações em tempo real
- [ ] Dashboard mobile responsivo
- [ ] Exportação de relatórios em PDF
- [ ] Integração com sistemas de pagamento
- [ ] Multi-idioma (i18n)
- [ ] Dark mode melhorado
- [ ] Analytics avançado

---

**NomadScan** - Veja Além. Controle Tudo. 🚁✨
