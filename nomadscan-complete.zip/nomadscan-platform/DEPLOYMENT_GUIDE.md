# 🚀 Guia Completo de Deployment - NomadScan

Este guia fornece instruções passo a passo para publicar a plataforma NomadScan no GitHub e fazer deploy no Vercel.

## 📋 Pré-requisitos

- Conta GitHub
- Conta Vercel
- Git instalado localmente
- Acesso às credenciais Manus (App ID, OAuth URL, etc)
- Banco de dados MySQL/TiDB configurado

## 🔧 Passo 1: Preparar o Repositório Local

### 1.1 Inicializar Git (se não estiver já)

```bash
cd nomadscan-platform
git init
git config user.name "Seu Nome"
git config user.email "seu.email@example.com"
```

### 1.2 Adicionar todos os arquivos

```bash
git add .
```

### 1.3 Criar primeiro commit

```bash
git commit -m "Initial commit: NomadScan platform with all features"
```

## 📤 Passo 2: Publicar no GitHub

### 2.1 Criar repositório no GitHub

1. Acesse [github.com/new](https://github.com/new)
2. Preencha os campos:
   - **Repository name**: `nomadscan-platform`
   - **Description**: `Plataforma de monitoramento de drones com IA`
   - **Visibility**: Escolha entre Public ou Private
   - **Initialize this repository**: Deixe desmarcado (já temos commits locais)
3. Clique em "Create repository"

### 2.2 Conectar repositório remoto

Após criar o repositório, execute:

```bash
git branch -M main
git remote add origin https://github.com/seu-usuario/nomadscan-platform.git
git push -u origin main
```

### 2.3 Verificar no GitHub

Acesse `https://github.com/seu-usuario/nomadscan-platform` para confirmar que o código foi enviado.

## 🚀 Passo 3: Deploy no Vercel

### 3.1 Conectar Vercel ao GitHub

1. Acesse [vercel.com](https://vercel.com)
2. Faça login com sua conta GitHub
3. Clique em "New Project"
4. Selecione "Import Git Repository"
5. Procure por "nomadscan-platform"
6. Clique em "Import"

### 3.2 Configurar Variáveis de Ambiente

Na tela de configuração do Vercel, adicione as seguintes variáveis:

**Database:**
```
DATABASE_URL = mysql://user:password@host:3306/nomadscan
```

**Authentication:**
```
JWT_SECRET = [gere uma string aleatória de 32+ caracteres]
VITE_APP_ID = [seu App ID do Manus]
OAUTH_SERVER_URL = https://api.manus.im
VITE_OAUTH_PORTAL_URL = https://manus.im/oauth
```

**Manus APIs:**
```
BUILT_IN_FORGE_API_URL = https://forge.manus.im
BUILT_IN_FORGE_API_KEY = [sua chave de API]
VITE_FRONTEND_FORGE_API_KEY = [sua chave frontend]
VITE_FRONTEND_FORGE_API_URL = https://forge.manus.im
```

**Owner Information:**
```
OWNER_NAME = [seu nome]
OWNER_OPEN_ID = [seu open ID do Manus]
```

### 3.3 Configurar Build Settings

- **Framework Preset**: Other
- **Build Command**: `pnpm run build`
- **Output Directory**: `dist`
- **Install Command**: `pnpm install`

### 3.4 Deploy

Clique em "Deploy" e aguarde a conclusão. Você receberá uma URL como:
```
https://nomadscan-platform.vercel.app
```

## 🌐 Passo 4: Configurar Domínio Customizado (Opcional)

### 4.1 Adicionar domínio no Vercel

1. Na dashboard do Vercel, vá para o projeto
2. Clique em "Settings" > "Domains"
3. Clique em "Add Domain"
4. Digite seu domínio (ex: `nomadscan.com`)
5. Clique em "Add"

### 4.2 Configurar DNS

Vercel fornecerá registros DNS. Configure-os no seu provedor de domínio:

- **CNAME Record**: Aponte para `cname.vercel-dns.com`
- Ou use os registros A fornecidos

### 4.3 Verificar Configuração

Aguarde até 48 horas para a propagação DNS. Seu site estará disponível em:
```
https://seu-dominio.com
```

## 🔄 Passo 5: Atualizações e Manutenção

### 5.1 Fazer alterações locais

```bash
# Faça suas alterações nos arquivos
git add .
git commit -m "Descrição da mudança"
git push origin main
```

### 5.2 Deploy automático

Vercel fará deploy automaticamente quando você fizer push para `main`.

### 5.3 Monitorar Deployments

1. Acesse a dashboard do Vercel
2. Clique no seu projeto
3. Veja o histórico de deployments em "Deployments"

## 🔐 Passo 6: Segurança

### 6.1 Proteger Secrets

- **Nunca** commite arquivos `.env`
- Use apenas variáveis de ambiente no Vercel
- Rotacione chaves de API regularmente

### 6.2 Configurar Branch Protection

1. No GitHub, vá para "Settings" > "Branches"
2. Clique em "Add rule"
3. Configure proteção para a branch `main`
4. Exija pull request reviews antes de merge

### 6.3 Habilitar HTTPS

Vercel habilita HTTPS automaticamente para todos os domínios.

## 📊 Passo 7: Monitoramento

### 7.1 Verificar Logs

No Vercel:
1. Vá para "Deployments"
2. Clique no deployment
3. Veja os logs em "Logs"

### 7.2 Monitorar Performance

1. Vá para "Analytics"
2. Verifique métricas de performance
3. Monitore erros e latência

### 7.3 Configurar Alertas

1. Vá para "Settings" > "Alerts"
2. Configure notificações para falhas de deployment

## 🆘 Troubleshooting

### Erro: "Build failed"

**Solução:**
1. Verifique os logs no Vercel
2. Confirme que todas as variáveis de ambiente estão configuradas
3. Execute `pnpm run build` localmente para testar

### Erro: "Database connection failed"

**Solução:**
1. Verifique se a `DATABASE_URL` está correta
2. Confirme que o banco de dados está acessível de fora (não está em firewall)
3. Teste a conexão localmente

### Erro: "OAuth callback failed"

**Solução:**
1. Verifique `VITE_APP_ID` e `OAUTH_SERVER_URL`
2. Configure o callback URL no Manus dashboard como: `https://seu-dominio.com/api/oauth/callback`
3. Limpe o cache do navegador

### Erro: "S3 upload failed"

**Solução:**
1. Verifique as credenciais de S3
2. Confirme permissões do bucket
3. Verifique se a região do bucket está correta

## 📚 Recursos Adicionais

- [Documentação Vercel](https://vercel.com/docs)
- [Documentação GitHub](https://docs.github.com)
- [Documentação Manus](https://manus.im/docs)
- [Documentação MySQL](https://dev.mysql.com/doc)

## ✅ Checklist Final

Antes de considerar o deployment completo:

- [ ] Repositório criado no GitHub
- [ ] Código enviado para GitHub
- [ ] Projeto criado no Vercel
- [ ] Todas as variáveis de ambiente configuradas
- [ ] Deploy realizado com sucesso
- [ ] Site acessível em `vercel.app`
- [ ] Domínio customizado configurado (se aplicável)
- [ ] HTTPS funcionando
- [ ] Login OAuth testado
- [ ] Dashboard carregando corretamente
- [ ] Banco de dados conectado
- [ ] S3 upload funcionando

---

**Parabéns! 🎉 Sua plataforma NomadScan está no ar!**

Para suporte adicional, consulte a documentação ou abra uma issue no GitHub.
